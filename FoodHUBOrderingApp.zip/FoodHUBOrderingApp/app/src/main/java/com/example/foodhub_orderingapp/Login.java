package com.example.foodhub_orderingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login extends AppCompatActivity {

    // Creation of Database class to access firebase realtime database
    DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReferenceFromUrl("https://foodhubordering-d69d0-default-rtdb.asia-southeast1.firebasedatabase.app\n" +
            "\n");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final EditText email = findViewById(R.id.email);
        final EditText password = findViewById(R.id.password);
        final Button LoginBtn = findViewById(R.id.LoginBTN);
        final TextView RegisterBtn = findViewById(R.id.RegisterNow);


        LoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                    final  String emailTxt = email.getText().toString();
                    final  String passwordTxt = password.getText().toString();

                    if(emailTxt.isEmpty() || passwordTxt.isEmpty()){
                        Toast.makeText(Login.this, "Please enter your email or password", Toast.LENGTH_SHORT).show();
                    }
                    else   {

                        databaseReference.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {


                                if (snapshot.hasChild(PhoneTxt)){

                                    final String getPassword = snapshot.child(PhoneTxt).child("Password").getValue(String.class);

                                    if (getPassword.equals((passwordTxt)) {
                                        Toast.makeText(Login.this, "Login Successfully" , Toast.LENGTH_SHORT).show();


                                        startActivity(new Intent(Login.this, MainActivity.class));
                                        finish();
                                    }
                                    else  {
                                        Toast.makeText(Login.this, "Wrong Password", Toast.LENGTH_SHORT).show();
                                    }
                                }
                                    else {
                                        Toast.makeText(Login.this, "Please Try Again", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });
                    }
            }
        });

        RegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // this method opens the registration activity
                startActivity(new Intent(Login.this, Registration.class));
            }
        });
    }
}