package com.example.foodhub_orderingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

public class Registration extends AppCompatActivity {


    // Creation of Database class to access firebase realtime database
    DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReferenceFromUrl("https://foodhubordering-d69d0-default-rtdb.asia-southeast1.firebasedatabase.app\n" +
            "\n");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        //              Variable Names                 Target EditText & Button
        final EditText firstname = findViewById(R.id.firstname);
        final EditText lastname = findViewById(R.id.lastname);
        final EditText phone = findViewById(R.id.phone);
        final EditText email = findViewById(R.id.email);
        final EditText password = findViewById(R.id.password);
        final EditText conPassword = findViewById(R.id.conPassword);

        final Button registerBTN = findViewById(R.id.registerBTN);
        final TextView loginNowBTN = findViewById(R.id.LoginNow);

        registerBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // this method gets data from EditTexts and converts into String variables/value.
                final String firstnameTxt = firstname.getText().toString();
                final String lastnameTxt = lastname.getText().toString();
                final String PhoneTxt = phone.getText().toString();
                final String emailTxt = email.getText().toString();
                final String passwordTxt = password.getText().toString();
                final String conPasswordTxt = conPassword.getText().toString();

                // This checks the user if all the fields has input before sending data to the Firestore database

                if (firstnameTxt.isEmpty() || lastnameTxt.isEmpty() || emailTxt.isEmpty() || PhoneTxt.isEmpty() || passwordTxt.isEmpty() || conPasswordTxt.isEmpty()){
                    Toast.makeText(Registration.this, "Please Fill all the Fields!", Toast.LENGTH_SHORT).show();
                }

                // Checks if the passwords are matching with each other
                // If it's not matching with the input then show an error message
                else if (passwordTxt.equals(conPassword));{
                    Toast.makeText(Registration.this, "Password aren't matched!", Toast.LENGTH_SHORT).show();
                }
                // sending data to the Firebase Realtime Database
                // The use of phone number as identifier of the user information under all the other details to make it unique

                else  {

                    databaseReference.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {

                            // checks if device is not registered
                            if (snapshot.hasChild(PhoneTxt)){
                                Toast.makeText(Registration.this, "Device is already registered",Toast.LENGTH_SHORT).show();

                                else {
                                    databaseReference.child("Users").child(PhoneTxt).child("First Name").setValue(firstname);
                                    databaseReference.child("Users").child(PhoneTxt).child("Last Name").setValue(lastname);
                                    databaseReference.child("Users").child(PhoneTxt).child("Email").setValue(email);
                                    databaseReference.child("Users").child(PhoneTxt).child("Password").setValue(password);


                                    // Displays a success message
                                    Toast.makeText(Registration.this, "User Registered Succefull!", Toast.LENGTH_SHORT).show();
                                    finish();
                                }

                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }
        }); }

        loginNowBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}